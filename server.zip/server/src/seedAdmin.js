import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();
const mobile = process.env.ADMIN_MOBILE;
const password = process.env.ADMIN_PASSWORD;
if (!mobile || !password) throw new Error('Set ADMIN_MOBILE and ADMIN_PASSWORD in .env');
const passwordHash = await bcrypt.hash(password, 12);
await prisma.user.upsert({
  where: { mobile },
  update: { passwordHash, role: 'ADMIN' },
  create: { mobile, passwordHash, role: 'ADMIN' }
});
console.log('Admin account created/updated.');
await prisma.$disconnect();
