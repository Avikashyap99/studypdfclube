import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import Razorpay from 'razorpay';
import { PrismaClient } from '@prisma/client';

const app = express();
const prisma = new PrismaClient();
const PORT = process.env.PORT || 4000;
const uploadDir = path.resolve('uploads');
fs.mkdirSync(uploadDir, { recursive: true });

app.use(cors({ origin: process.env.FRONTEND_URL, credentials: true }));
app.use('/api', rateLimit({ windowMs: 15 * 60 * 1000, limit: 250 }));
// Razorpay webhook needs the raw request body for signature verification.
app.post('/api/payments/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  try {
    const signature = req.headers['x-razorpay-signature'];
    const expected = crypto.createHmac('sha256', process.env.RAZORPAY_WEBHOOK_SECRET)
      .update(req.body).digest('hex');
    if (!signature || !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) {
      return res.status(400).send('Invalid webhook signature');
    }
    const event = JSON.parse(req.body.toString('utf8'));
    const entity = event.payload?.subscription?.entity;
    if (entity?.id) {
      const statusMap = {
        created: 'CREATED', authenticated: 'AUTHENTICATED', activated: 'ACTIVE',
        pending: 'CREATED', halted: 'HALTED', cancelled: 'CANCELLED',
        completed: 'COMPLETED', expired: 'EXPIRED'
      };
      const status = statusMap[entity.status];
      if (status) {
        await prisma.subscription.updateMany({
          where: { razorpaySubscriptionId: entity.id },
          data: {
            status,
            currentStart: entity.current_start ? new Date(entity.current_start * 1000) : undefined,
            currentEnd: entity.current_end ? new Date(entity.current_end * 1000) : undefined
          }
        });
      }
    }
    res.json({ received: true });
  } catch (e) {
    console.error('Webhook error:', e);
    res.status(500).send('Webhook processing failed');
  }
});
app.use(express.json());

const razorpay = process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET
  ? new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET })
  : null;

function auth(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch { res.status(401).json({ error: 'Please log in again.' }); }
}
function admin(req, res, next) {
  if (req.user?.role !== 'ADMIN') return res.status(403).json({ error: 'Admin access required.' });
  next();
}
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => cb(null, `${crypto.randomUUID()}${path.extname(file.originalname).toLowerCase()}`)
});
const pdfUpload = multer({
  storage, limits: { fileSize: 20 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => cb(null, file.mimetype === 'application/pdf' && path.extname(file.originalname).toLowerCase() === '.pdf')
});

app.get('/api/health', (_req, res) => res.json({ ok: true }));
app.post('/api/auth/register', async (req, res) => {
  const { mobile, password } = req.body || {};
  if (!/^[6-9]\d{9}$/.test(mobile || '') || typeof password !== 'string' || password.length < 8)
    return res.status(400).json({ error: 'Enter a valid 10-digit Indian mobile number and password of at least 8 characters.' });
  try {
    const passwordHash = await bcrypt.hash(password, 12);
    const user = await prisma.user.create({ data: { mobile, passwordHash } });
    const token = jwt.sign({ id: user.id, role: user.role, mobile: user.mobile }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.status(201).json({ token, user: { mobile: user.mobile, role: user.role } });
  } catch { res.status(409).json({ error: 'This mobile number is already registered.' }); }
});
app.post('/api/auth/login', async (req, res) => {
  const { mobile, password } = req.body || {};
  const user = await prisma.user.findUnique({ where: { mobile } });
  if (!user || !(await bcrypt.compare(password || '', user.passwordHash)))
    return res.status(401).json({ error: 'Incorrect mobile number or password.' });
  const token = jwt.sign({ id: user.id, role: user.role, mobile: user.mobile }, process.env.JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { mobile: user.mobile, role: user.role } });
});
app.get('/api/pdfs', auth, async (req, res) => {
  const { classNo, subject } = req.query;
  const sub = await prisma.subscription.findUnique({ where: { userId: req.user.id } });
  if (!sub || sub.status !== 'ACTIVE') return res.status(403).json({ error: 'An active monthly subscription is required.' });
  const where = {};
  if ([8, 9, 10].includes(Number(classNo))) where.classNo = Number(classNo);
  if (['Science', 'Mathematics'].includes(subject)) where.subject = subject;
  res.json(await prisma.pdf.findMany({ where, select: { id: true, title: true, classNo: true, subject: true, createdAt: true } }));
});
app.get('/api/pdfs/:id/download', auth, async (req, res) => {
  const sub = await prisma.subscription.findUnique({ where: { userId: req.user.id } });
  if (!sub || sub.status !== 'ACTIVE') return res.status(403).json({ error: 'Active subscription required.' });
  const pdf = await prisma.pdf.findUnique({ where: { id: req.params.id } });
  if (!pdf) return res.status(404).json({ error: 'PDF not found.' });
  res.download(pdf.filePath, pdf.fileName);
});
app.post('/api/admin/pdfs', auth, admin, pdfUpload.single('pdf'), async (req, res) => {
  const { title, classNo, subject } = req.body;
  const c = Number(classNo);
  if (!req.file) return res.status(400).json({ error: 'Upload a PDF file only (maximum 20 MB).' });
  if (![8,9,10].includes(c) || !['Science','Mathematics'].includes(subject) || !title?.trim()) {
    fs.unlinkSync(req.file.path);
    return res.status(400).json({ error: 'Choose class 8, 9 or 10 and Science or Mathematics.' });
  }
  const pdf = await prisma.pdf.create({ data: { title: title.trim(), classNo: c, subject, fileName: req.file.originalname, filePath: req.file.path } });
  res.status(201).json(pdf);
});
app.delete('/api/admin/pdfs/:id', auth, admin, async (req, res) => {
  const pdf = await prisma.pdf.findUnique({ where: { id: req.params.id } });
  if (!pdf) return res.status(404).json({ error: 'PDF not found.' });
  await prisma.pdf.delete({ where: { id: pdf.id } });
  if (fs.existsSync(pdf.filePath)) fs.unlinkSync(pdf.filePath);
  res.json({ ok: true });
});
app.post('/api/payments/create-subscription', auth, async (req, res) => {
  if (!razorpay || !process.env.RAZORPAY_PLAN_ID) return res.status(503).json({ error: 'Payment gateway is not configured yet.' });
  try {
    const created = await razorpay.subscriptions.create({
      plan_id: process.env.RAZORPAY_PLAN_ID, total_count: 120,
      quantity: 1, customer_notify: 1,
      notes: { userId: req.user.id, mobile: req.user.mobile }
    });
    await prisma.subscription.upsert({
      where: { userId: req.user.id },
      create: { userId: req.user.id, razorpaySubscriptionId: created.id, status: 'CREATED' },
      update: { razorpaySubscriptionId: created.id, status: 'CREATED' }
    });
    res.json({ subscriptionId: created.id, keyId: process.env.RAZORPAY_KEY_ID });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Could not create subscription. Check Razorpay plan and API keys.' });
  }
});
app.get('/api/me', auth, async (req, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.user.id }, include: { subscription: true } });
  res.json({ mobile: user.mobile, role: user.role, subscription: user.subscription });
});
app.listen(PORT, () => console.log(`StudyPDFClub API running on ${PORT}`));
