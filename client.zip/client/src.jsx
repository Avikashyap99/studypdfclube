import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './style.css';
const API = import.meta.env.VITE_API_URL || 'http://localhost:4000';
function App() {
  const [token,setToken]=useState(localStorage.getItem('token')||'');
  const [mobile,setMobile]=useState(''), [password,setPassword]=useState('');
  const [mode,setMode]=useState('login'), [me,setMe]=useState(null), [message,setMessage]=useState('');
  const [classNo,setClassNo]=useState('8'), [subject,setSubject]=useState('Science'), [pdfs,setPdfs]=useState([]);
  const [title,setTitle]=useState(''), [file,setFile]=useState(null);
  const headers=()=>({Authorization:`Bearer ${token}`});
  async function request(path, options={}) {
    const r=await fetch(API+path,{...options,headers:{...headers(),...(options.headers||{})}});
    const data=await r.json().catch(()=>({}));
    if(!r.ok) throw new Error(data.error||'Request failed');
    return data;
  }
  async function submitAuth(e) {
    e.preventDefault(); setMessage('');
    try {
      const data=await request(`/api/auth/${mode}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mobile,password})});
      localStorage.setItem('token',data.token); setToken(data.token); setMessage('Login successful');
    } catch(e){setMessage(e.message);}
  }
  async function load() {
    try { const u=await request('/api/me'); setMe(u); }
    catch { setToken(''); localStorage.removeItem('token'); }
  }
  useEffect(()=>{if(token)load();},[token]);
  async function loadPdfs() {
    try {setPdfs(await request(`/api/pdfs?classNo=${classNo}&subject=${subject}`));}
    catch(e){setMessage(e.message);setPdfs([]);}
  }
  async function subscribe() {
    try {
      const d=await request('/api/payments/create-subscription',{method:'POST'});
      const script=document.createElement('script'); script.src='https://checkout.razorpay.com/v1/checkout.js';
      script.onload=()=>{
        const checkout=new window.Razorpay({key:d.keyId,subscription_id:d.subscriptionId,name:'StudyPDFClub',description:'₹354 monthly subscription',handler:()=>setMessage('Payment submitted. Subscription activates after verified Razorpay webhook.'),theme:{color:'#2457d6'}});
        checkout.open();
      };
      document.body.appendChild(script);
    } catch(e){setMessage(e.message);}
  }
  async function upload(e) {
    e.preventDefault(); if(!file) return setMessage('Select a PDF first');
    const fd=new FormData(); fd.append('title',title); fd.append('classNo',classNo); fd.append('subject',subject); fd.append('pdf',file);
    try {await request('/api/admin/pdfs',{method:'POST',body:fd});setMessage('PDF uploaded');setTitle('');setFile(null);}
    catch(e){setMessage(e.message);}
  }
  if(!token) return <main className="auth"><section className="panel"><h1>Study<span>PDF</span>Club</h1><p>Learn smarter. Prepare better.</p><form onSubmit={submitAuth}><input required value={mobile} onChange={e=>setMobile(e.target.value)} placeholder="10-digit mobile number" maxLength="10"/><input required type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password (minimum 8 characters)"/><button>{mode==='login'?'Login':'Create account'}</button></form><button className="link" onClick={()=>setMode(mode==='login'?'register':'login')}>{mode==='login'?'New student? Create account':'Already registered? Login'}</button>{message&&<p className="msg">{message}</p>}</section></main>;
  return <main><header><h1>Study<span>PDF</span>Club</h1><div>{me?.mobile} <button className="small" onClick={()=>{localStorage.removeItem('token');setToken('');}}>Logout</button></div></header>
    {message&&<p className="msg">{message}</p>}
    <section className="panel"><h2>Student Library</h2><div className="filters"><select value={classNo} onChange={e=>setClassNo(e.target.value)}><option value="8">Class 8</option><option value="9">Class 9</option><option value="10">Class 10</option></select><select value={subject} onChange={e=>setSubject(e.target.value)}><option>Science</option><option>Mathematics</option></select><button onClick={loadPdfs}>Show PDFs</button></div><button onClick={subscribe}>Subscribe — ₹354 / month</button><div className="pdfs">{pdfs.map(p=><article key={p.id}><b>{p.title}</b><p>Class {p.classNo} · {p.subject}</p><a href={`${API}/api/pdfs/${p.id}/download`} onClick={async e=>{e.preventDefault();try{const r=await fetch(`${API}/api/pdfs/${p.id}/download`,{headers:headers()});if(!r.ok)throw new Error('Download failed');const blob=await r.blob();const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=p.title+'.pdf';a.click();URL.revokeObjectURL(a.href);}catch(err){setMessage(err.message);}}}>Download PDF</a></article>)}</div></section>
    {me?.role==='ADMIN'&&<section className="panel"><h2>Admin — Upload PDF</h2><form onSubmit={upload}><input required value={title} onChange={e=>setTitle(e.target.value)} placeholder="PDF title"/><div className="filters"><select value={classNo} onChange={e=>setClassNo(e.target.value)}><option value="8">Class 8</option><option value="9">Class 9</option><option value="10">Class 10</option></select><select value={subject} onChange={e=>setSubject(e.target.value)}><option>Science</option><option>Mathematics</option></select></div><input type="file" accept="application/pdf" onChange={e=>setFile(e.target.files[0])}/><button>Upload PDF</button></form></section>}
  </main>;
}
createRoot(document.getElementById('root')).render(<App/>);
